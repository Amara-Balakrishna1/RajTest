import React, {
  Component
} from 'react';

export default class TravelPlan extends Component {
  render() {
    return (
      <div name="redx">
        Hi Hari ? asdf
      </div>
    );
  }
}
