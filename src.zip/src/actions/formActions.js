export default function addForm() {
  return (dispatch) => {
    dispatch({
      type: 'ADD_FORM'
    });
  };
}
