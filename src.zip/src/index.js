import React, { Component } from 'react';
import ReactDOM from 'react-dom';

import { Provider } from 'react-redux';

// We'll create this in step 3.
import store from './store/store';

// We'll create this in step 4.
// import Forms from './components';

// import EventForm from './components/event_expense';

import TourPlan from './components/TourPlan';

class App extends Component {
  render() {
    return (
      <Provider store={ store }>
        <TourPlan />
      </Provider>
    );
  }
}

ReactDOM.render(<App />, document.getElementById('app-root'));
