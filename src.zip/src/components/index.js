import React, { Component } from 'react';
// import UserForm from './UserForm';
// import FieldArraysForm from './fieldArrays';
import Home from './home';

// function showResults(values) {
//   alert(JSON.stringify(values, null, 2));
// }

export default class Forms extends Component {
  render() {
    return (
      <div className="app">
        <Home />
      </div>
    );
  }
}
