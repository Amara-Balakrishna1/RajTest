import React from 'react';
import { Field, reduxForm } from 'redux-form';
import './signin.css';

const SimpleSignin = props => {
  const {
    handleSubmit,
    pristine,
    submitting
  } = props;
  return (
    <form onSubmit={handleSubmit} className="signin">
      <div>
        <label>User Name</label>
        <div>
          <Field
            name="firstName"
            component="input"
            type="text"
            placeholder="User Name"
          />
        </div>
      </div>
      <div>
        <label>password</label>
        <div>
          <Field
            name="lastName"
            component="input"
            type="password"
            placeholder="password"
          />
        </div>
      </div>
      <div className="adminCheck">
        <label>
          <Field
            name="Admin"
            component="input"
            type="checkbox"
          />
          Admin
        </label>
      </div>
      <div>
        <button type="submit" disabled={pristine || submitting}>
          Login
        </button>
      </div>
    </form>
  );
};

export default reduxForm({
  form: 'SimpleSignin' // a unique identifier for this form
})(SimpleSignin);
